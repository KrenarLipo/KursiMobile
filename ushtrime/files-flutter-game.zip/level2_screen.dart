// lib/level2_screen.dart

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'models/game_state.dart';
import 'widgets/player_lives_widget.dart';

class Level2Screen extends StatefulWidget {
  final GameState gameState;
  final VoidCallback onWin;
  final VoidCallback onGameOver;

  const Level2Screen({
    required this.gameState,
    required this.onWin,
    required this.onGameOver,
    super.key,
  });

  @override
  State<Level2Screen> createState() => _Level2ScreenState();
}

class _Level2ScreenState extends State<Level2Screen>
    with SingleTickerProviderStateMixin {
  // ── Boss ────────────────────────────────────────────────────────────────
  int bossHp = 200;
  final int maxBossHp = 200;
  bool get bossIsDead => bossHp <= 0;
  double get bossHpPercent => bossHp / maxBossHp;

  // ── Laser ────────────────────────────────────────────────────────────────
  Timer? _laserTimer;
  Timer? _laserMoveTimer;
  bool _laserVisible = false;
  double _laserTopPercent = 0.15; // fraction of screen height (0=top)
  double _laserLeftPercent = 0.5; // fraction of screen width  (0=left)
  bool _playerHitFlash = false;

  // ── Boss shake ────────────────────────────────────────────────────────────
  late AnimationController _bossShakeCtrl;
  late Animation<double> _bossShakeAnim;

  final _rng = Random();

  // Speed: 1500ms at full HP → 400ms at 0 HP
  Duration get _laserInterval {
    final pct = bossHp / maxBossHp; // 1.0 → 0.0
    final ms = 400 + (pct * 1100).toInt();
    return Duration(milliseconds: ms);
  }

  // Laser travel speed: faster at low HP
  Duration get _laserMoveInterval {
    final pct = bossHp / maxBossHp;
    final ms = 12 + (pct * 18).toInt(); // 12ms–30ms per tick
    return Duration(milliseconds: ms);
  }

  @override
  void initState() {
    super.initState();
    _bossShakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    );
    _bossShakeAnim = Tween<double>(begin: 0, end: 10).animate(
      CurvedAnimation(parent: _bossShakeCtrl, curve: Curves.elasticIn),
    );
    _scheduleNextLaser();
  }

  @override
  void dispose() {
    _laserTimer?.cancel();
    _laserMoveTimer?.cancel();
    _bossShakeCtrl.dispose();
    super.dispose();
  }

  // ── Laser logic ─────────────────────────────────────────────────────────

  void _scheduleNextLaser() {
    _laserTimer?.cancel();
    _laserTimer = Timer(_laserInterval, () {
      if (!mounted) return;
      _fireLaser();
    });
  }

  void _fireLaser() {
    if (bossIsDead || !mounted) return;
    _laserMoveTimer?.cancel();

    final startX = 0.15 + _rng.nextDouble() * 0.70; // random column

    setState(() {
      _laserVisible = true;
      _laserTopPercent = 0.18;
      _laserLeftPercent = startX;
    });

    // Animate laser moving downward tick by tick
    _laserMoveTimer = Timer.periodic(_laserMoveInterval, (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() => _laserTopPercent += 0.030);

      // Laser has reached the player zone (bottom 15%)
      if (_laserTopPercent >= 0.80) {
        t.cancel();
        _onLaserReachedPlayer();
      }
    });
  }

  void _onLaserReachedPlayer() {
    // Player is centred; hit if laser X is within ±12% of centre
    final hit = (_laserLeftPercent - 0.50).abs() < 0.12;

    setState(() => _laserVisible = false);

    if (hit) {
      _triggerHitFlash();
      widget.gameState.takeDamage();
      if (!widget.gameState.isAlive) {
        _laserTimer?.cancel();
        widget.onGameOver();
        return;
      }
      setState(() {}); // Refresh lives display
    }

    // Schedule next laser
    _scheduleNextLaser();
  }

  void _triggerHitFlash() {
    setState(() => _playerHitFlash = true);
    Future.delayed(const Duration(milliseconds: 350), () {
      if (mounted) setState(() => _playerHitFlash = false);
    });
  }

  // ── Player shoots boss ───────────────────────────────────────────────────

  void _shootBoss() {
    if (bossIsDead) return;
    setState(() {
      bossHp = (bossHp - 25).clamp(0, maxBossHp);
    });
    _bossShakeCtrl.forward(from: 0);

    if (bossIsDead) {
      _laserTimer?.cancel();
      _laserMoveTimer?.cancel();
      setState(() => _laserVisible = false);
      widget.onWin();
    }
  }

  // ── Build ────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: _buildAppBar(),
      body: SafeArea(
        child: Stack(
          children: [
            // ── Main content ────────────────────────────────────────────
            _buildMainContent(context),

            // ── Laser beam overlay ──────────────────────────────────────
            if (_laserVisible) _buildLaser(context),

            // ── Hit flash overlay ───────────────────────────────────────
            if (_playerHitFlash)
              Positioned.fill(
                child: IgnorePointer(
                  child: Container(
                    color: const Color(0xFFF85149).withOpacity(0.25),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: const Color(0xFF161B22),
      title: const Text(
        'Level 2  —  Android Boss',
        style: TextStyle(
          color: Color(0xFFF85149),
          fontWeight: FontWeight.bold,
          letterSpacing: 1,
        ),
      ),
      centerTitle: true,
      elevation: 0,
    );
  }

  Widget _buildMainContent(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Column(
        children: [
          _buildLevelBadge(),
          const SizedBox(height: 20),

          // ── Boss section ──────────────────────────────────────────────
          _buildBossImage(),
          const SizedBox(height: 16),
          _buildBossHpBar(),
          const SizedBox(height: 24),

          // ── Divider ───────────────────────────────────────────────────
          const Divider(color: Color(0xFF21262D), thickness: 1),
          const SizedBox(height: 16),

          // ── Player section ────────────────────────────────────────────
          const Text(
            'YOUR LIVES',
            style: TextStyle(
              color: Color(0xFF8B949E),
              fontSize: 11,
              letterSpacing: 2,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          PlayerLivesWidget(lives: widget.gameState.playerLives),
          const SizedBox(height: 20),

          _buildLaserWarning(),
          const SizedBox(height: 20),

          // ── Shoot button ──────────────────────────────────────────────
          ElevatedButton.icon(
            onPressed: _shootBoss,
            icon: const Icon(Icons.bolt_rounded, size: 22),
            label: const Text('FIRE AT BOSS'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFE3B341),
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
              textStyle: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
              ),
              shadowColor: const Color(0xFFE3B341),
              elevation: 8,
            ),
          ),

          const SizedBox(height: 60), // bottom spacing so laser is visible
        ],
      ),
    );
  }

  Widget _buildLevelBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF7F1D1D),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF85149), width: 1),
      ),
      child: const Text(
        '⚡  BOSS BATTLE',
        style: TextStyle(
          color: Color(0xFFF85149),
          fontWeight: FontWeight.bold,
          letterSpacing: 2,
          fontSize: 13,
        ),
      ),
    );
  }

  Widget _buildBossImage() {
    return AnimatedBuilder(
      animation: _bossShakeAnim,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(
            _bossShakeCtrl.isAnimating
                ? (_bossShakeAnim.value *
                    ((_bossShakeCtrl.value * 10).toInt().isEven ? 1 : -1))
                : 0,
            0,
          ),
          child: child,
        );
      },
      child: Container(
        width: 200,
        height: 200,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF161B22),
          border: Border.all(color: const Color(0xFFF85149), width: 3),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF85149).withOpacity(0.4),
              blurRadius: 28,
              spreadRadius: 6,
            ),
          ],
        ),
        padding: const EdgeInsets.all(12),
        child: ClipOval(
          child: Image.asset('assets/boss.jpg', fit: BoxFit.cover),
        ),
      ),
    );
  }

  Widget _buildBossHpBar() {
    final barColor = bossHpPercent > 0.5
        ? const Color(0xFFE3B341)
        : bossHpPercent > 0.25
            ? const Color(0xFFE88C1A)
            : const Color(0xFFF85149);

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'BOSS HP',
              style: TextStyle(
                color: Color(0xFF8B949E),
                fontSize: 11,
                letterSpacing: 2,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '$bossHp / $maxBossHp',
              style: TextStyle(
                color: barColor,
                fontSize: 13,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 1.0, end: bossHpPercent),
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeOut,
            builder: (context, value, _) {
              return LinearProgressIndicator(
                value: value,
                minHeight: 20,
                backgroundColor: const Color(0xFF21262D),
                valueColor: AlwaysStoppedAnimation<Color>(barColor),
              );
            },
          ),
        ),
        const SizedBox(height: 6),
        // Laser speed indicator
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.speed_rounded, size: 14, color: Color(0xFF8B949E)),
            const SizedBox(width: 4),
            Text(
              'Laser speed: ${_laserSpeedLabel()}',
              style: const TextStyle(
                color: Color(0xFF8B949E),
                fontSize: 11,
              ),
            ),
          ],
        ),
      ],
    );
  }

  String _laserSpeedLabel() {
    if (bossHpPercent > 0.66) return '🟢 Slow';
    if (bossHpPercent > 0.33) return '🟡 Medium';
    return '🔴 FAST!';
  }

  Widget _buildLaserWarning() {
    if (!_laserVisible) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF161B22),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xFF30363D)),
        ),
        child: const Text(
          '🛡️  Dodge the laser — it fires near centre!',
          style: TextStyle(color: Color(0xFF8B949E), fontSize: 12),
          textAlign: TextAlign.center,
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF7F1D1D),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFF85149)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.warning_rounded, color: Color(0xFFF85149), size: 18),
          SizedBox(width: 8),
          Text(
            'LASER INCOMING!',
            style: TextStyle(
              color: Color(0xFFF85149),
              fontWeight: FontWeight.bold,
              fontSize: 13,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLaser(BuildContext context) {
    final screenH = MediaQuery.of(context).size.height;
    final screenW = MediaQuery.of(context).size.width;

    return Positioned(
      left: screenW * _laserLeftPercent - 3, // centre the 6px wide beam
      top: screenH * _laserTopPercent,
      child: Container(
        width: 6,
        height: 55,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF00FFFF), Color(0xFF0088FF)],
          ),
          borderRadius: BorderRadius.circular(3),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF00FFFF).withOpacity(0.9),
              blurRadius: 14,
              spreadRadius: 4,
            ),
          ],
        ),
      ),
    );
  }
}
