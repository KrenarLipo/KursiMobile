// lib/models/game_state.dart

enum GameStatus { playing, gameOver, victory }

class GameState {
  int level;
  int playerLives;
  GameStatus status;

  GameState({
    this.level = 1,
    this.playerLives = 3,
    this.status = GameStatus.playing,
  });

  bool get isAlive => playerLives > 0;

  void takeDamage() {
    playerLives--;
    if (playerLives <= 0) {
      playerLives = 0;
      status = GameStatus.gameOver;
    }
  }

  void reset() {
    level = 1;
    playerLives = 3;
    status = GameStatus.playing;
  }
}
