// lib/widgets/player_lives_widget.dart

import 'package:flutter/material.dart';

class PlayerLivesWidget extends StatelessWidget {
  final int lives;
  final int maxLives;

  const PlayerLivesWidget({
    required this.lives,
    this.maxLives = 3,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(maxLives, (index) {
        final isAlive = index < lives;
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            transitionBuilder: (child, animation) => ScaleTransition(
              scale: animation,
              child: child,
            ),
            child: Icon(
              isAlive ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              key: ValueKey(isAlive),
              color: isAlive ? const Color(0xFFF85149) : const Color(0xFF30363D),
              size: 36,
            ),
          ),
        );
      }),
    );
  }
}
