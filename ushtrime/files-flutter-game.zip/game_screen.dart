// lib/game_screen.dart

import 'package:flutter/material.dart';
import 'models/game_state.dart';
import 'level1_screen.dart';
import 'level2_screen.dart';
import 'screens/game_over_screen.dart';
import 'screens/victory_screen.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  // Single source of truth for the whole game
  final GameState _state = GameState();

  void _goToLevel2() {
    setState(() => _state.level = 2);
  }

  void _restartGame() {
    setState(() => _state.reset());
  }

  void _triggerVictory() {
    setState(() => _state.status = GameStatus.victory);
  }

  void _triggerGameOver() {
    setState(() => _state.status = GameStatus.gameOver);
  }

  @override
  Widget build(BuildContext context) {
    // Game Over screen
    if (_state.status == GameStatus.gameOver) {
      return GameOverScreen(onRestart: _restartGame);
    }

    // Victory screen
    if (_state.status == GameStatus.victory) {
      return VictoryScreen(onRestart: _restartGame);
    }

    // Level 1 – Goblin
    if (_state.level == 1) {
      return Level1Screen(
        onNextLevel: _goToLevel2,
        onRestart: _restartGame,
      );
    }

    // Level 2 – Android Boss
    return Level2Screen(
      gameState: _state,
      onWin: _triggerVictory,
      onGameOver: _triggerGameOver,
    );
  }
}
