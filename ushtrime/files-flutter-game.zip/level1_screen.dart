// lib/level1_screen.dart

import 'package:flutter/material.dart';

class Level1Screen extends StatefulWidget {
  final VoidCallback onNextLevel;
  final VoidCallback onRestart;

  const Level1Screen({
    required this.onNextLevel,
    required this.onRestart,
    super.key,
  });

  @override
  State<Level1Screen> createState() => _Level1ScreenState();
}

class _Level1ScreenState extends State<Level1Screen>
    with SingleTickerProviderStateMixin {
  int goblinHp = 100;
  final int maxHp = 100;
  late AnimationController _shakeController;
  late Animation<double> _shakeAnimation;

  bool get isDead => goblinHp <= 0;
  double get hpPercent => goblinHp / maxHp;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _shakeAnimation = Tween<double>(begin: 0, end: 12).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticIn),
    );
  }

  @override
  void dispose() {
    _shakeController.dispose();
    super.dispose();
  }

  void _shoot() {
    if (isDead) return;
    setState(() {
      goblinHp = (goblinHp - 20).clamp(0, maxHp);
    });
    _shakeController.forward(from: 0);
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: _buildAppBar(),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildLevelBadge(),
                const SizedBox(height: 24),
                _buildGoblinImage(),
                const SizedBox(height: 28),
                _buildHealthBar(),
                const SizedBox(height: 28),
                _buildStatusText(),
                const SizedBox(height: 24),
                _buildActionButtons(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: const Color(0xFF161B22),
      title: const Text(
        'Level 1  —  Goblin',
        style: TextStyle(
          color: Color(0xFF3FB950),
          fontWeight: FontWeight.bold,
          letterSpacing: 1,
        ),
      ),
      centerTitle: true,
      elevation: 0,
    );
  }

  Widget _buildLevelBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF166534),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF3FB950), width: 1),
      ),
      child: const Text(
        '⚔️  DEFEAT THE GOBLIN',
        style: TextStyle(
          color: Color(0xFF3FB950),
          fontWeight: FontWeight.bold,
          letterSpacing: 2,
          fontSize: 13,
        ),
      ),
    );
  }

  Widget _buildGoblinImage() {
    return AnimatedBuilder(
      animation: _shakeAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(
            _shakeController.isAnimating
                ? (_shakeAnimation.value * ((_shakeController.value * 10).toInt().isEven ? 1 : -1))
                : 0,
            0,
          ),
          child: child,
        );
      },
      child: Container(
        width: 220,
        height: 220,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF161B22),
          border: Border.all(
            color: isDead ? const Color(0xFFF85149) : const Color(0xFF3FB950),
            width: 3,
          ),
          boxShadow: [
            BoxShadow(
              color: (isDead ? const Color(0xFFF85149) : const Color(0xFF3FB950))
                  .withOpacity(0.3),
              blurRadius: 24,
              spreadRadius: 4,
            ),
          ],
        ),
        padding: const EdgeInsets.all(12),
        child: ClipOval(
          child: Image.asset(
            isDead ? 'assets/goblin-dead.jpg' : 'assets/goblin-alive.webp',
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }

  Widget _buildHealthBar() {
    final barColor = hpPercent > 0.5
        ? const Color(0xFF3FB950)
        : hpPercent > 0.25
            ? const Color(0xFFE3B341)
            : const Color(0xFFF85149);

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'GOBLIN HP',
              style: TextStyle(
                color: Color(0xFF8B949E),
                fontSize: 11,
                letterSpacing: 2,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '$goblinHp / $maxHp',
              style: TextStyle(
                color: barColor,
                fontSize: 13,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 1.0, end: hpPercent),
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeOut,
            builder: (context, value, _) {
              return LinearProgressIndicator(
                value: value,
                minHeight: 20,
                backgroundColor: const Color(0xFF21262D),
                valueColor: AlwaysStoppedAnimation<Color>(barColor),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildStatusText() {
    if (isDead) {
      return const Column(
        children: [
          Text(
            '💀  GOBLIN DEFEATED!',
            style: TextStyle(
              color: Color(0xFFF85149),
              fontSize: 22,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          SizedBox(height: 6),
          Text(
            'Choose your next action:',
            style: TextStyle(color: Color(0xFF8B949E), fontSize: 14),
          ),
        ],
      );
    }
    return Text(
      'Tap the button to shoot the goblin!',
      style: TextStyle(
        color: Colors.white.withOpacity(0.7),
        fontSize: 14,
      ),
    );
  }

  Widget _buildActionButtons() {
    if (!isDead) {
      return ElevatedButton.icon(
        onPressed: _shoot,
        icon: const Icon(Icons.gps_fixed, size: 20),
        label: const Text('SHOOT GOBLIN'),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFF85149),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 16),
          textStyle: const TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
          shadowColor: const Color(0xFFF85149),
          elevation: 8,
        ),
      );
    }

    // Goblin is dead → show Next Level + Restart
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ElevatedButton.icon(
          onPressed: widget.onNextLevel,
          icon: const Icon(Icons.arrow_forward_rounded),
          label: const Text('NEXT LEVEL'),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF3FB950),
            foregroundColor: Colors.black,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
            textStyle: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
        ),
        const SizedBox(width: 16),
        OutlinedButton.icon(
          onPressed: widget.onRestart,
          icon: const Icon(Icons.replay_rounded),
          label: const Text('RESTART'),
          style: OutlinedButton.styleFrom(
            foregroundColor: const Color(0xFF8B949E),
            side: const BorderSide(color: Color(0xFF30363D), width: 1.5),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }
}
