# assets/images/

Place your sprite PNG files here before running the game.

Required files:

| Filename          | Purpose                        | Suggested size |
|-------------------|--------------------------------|----------------|
| player_ship.png   | Player's spaceship             | 60 × 80 px     |
| enemy_small.png   | Small enemy (−15 HP, +10 pts)  | 40 × 40 px     |
| enemy_large.png   | Large enemy (−20 HP, +25 pts)  | 64 × 64 px     |
| bullet.png        | Player bullet projectile       | 10 × 28 px     |
| stars_far.png     | Parallax background layer (far)  | screen size  |
| stars_near.png    | Parallax background layer (near) | screen size  |

## Free sprite packs

- https://kenney.nl/assets/space-shooter-redux  (CC0, no attribution required)
- https://opengameart.org/content/space-shooter-redux

## Audio files (optional — place in assets/audio/)

| Filename         | Purpose                |
|------------------|------------------------|
| shoot.wav        | Bullet fire sound      |
| explosion.wav    | Enemy destroyed sound  |
| game_over.mp3    | Game over jingle       |
| bg_music.mp3     | Background loop music  |

Free SFX: https://freesound.org
