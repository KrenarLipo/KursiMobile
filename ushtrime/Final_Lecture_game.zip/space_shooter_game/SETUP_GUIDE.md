# 🛠️ Complete Setup Guide — Space Shooter Game

Follow these steps in order to go from zero to a running game.

---

## STEP 1 — Prerequisites

| Tool | Version | Install |
|------|---------|---------|
| Flutter SDK | 3.22+ | https://docs.flutter.dev/get-started/install |
| Dart SDK | 3.3+ | Bundled with Flutter |
| Android Studio | Latest | For Android emulator / build tools |
| Xcode | 15+ (macOS only) | Mac App Store |
| Firebase CLI | Latest | `npm install -g firebase-tools` |
| FlutterFire CLI | Latest | `dart pub global activate flutterfire_cli` |
| Java (keytool) | 11+ | Bundled with Android Studio |

---

## STEP 2 — Clone / Open Project

```bash
# If using the zip:
unzip space_shooter_game.zip
cd space_shooter_game

# Install Flutter dependencies
flutter pub get
```

---

## STEP 3 — Firebase Project Setup

### 3a. Create Firebase project
1. Go to https://console.firebase.google.com
2. Click **Add project** → Name it (e.g. `space-shooter-game`)
3. Disable Google Analytics (optional) → **Create project**

### 3b. Enable Authentication
1. Build → **Authentication** → Get started
2. Sign-in method tab → **Email/Password** → Enable → Save

### 3c. Create Firestore Database
1. Build → **Firestore Database** → Create database
2. Choose **Start in test mode** (safe for development)
3. Select a region close to your users → **Done**

### 3d. Register Flutter app with FlutterFire CLI
```bash
# From inside the space_shooter_game directory:
flutterfire configure --project=YOUR_FIREBASE_PROJECT_ID

# This generates:
#   lib/firebase_options.dart             (Flutter config)
#   android/app/google-services.json      (Android config)
#   ios/Runner/GoogleService-Info.plist   (iOS config)
```

> ⚠️ The `lib/firebase_options.dart` in this zip is a **placeholder**.
> You MUST run `flutterfire configure` to replace it with real values.

---

## STEP 4 — Add Game Assets

Place your sprite images in `assets/images/`:

```
assets/images/
├── player_ship.png    # Player ship (suggested size: 60×80)
├── enemy_small.png    # Small enemy (suggested size: 40×40)
├── enemy_large.png    # Large enemy (suggested size: 64×64)
├── bullet.png         # Bullet (suggested size: 10×28)
├── stars_far.png      # Background star layer (full screen)
└── stars_near.png     # Foreground star layer (full screen)
```

**Free assets:** https://kenney.nl/assets/space-shooter-redux

The game runs without assets (you'll see invisible sprites with working hitboxes),
which is useful for logic testing before art is ready.

---

## STEP 5 — Run the App

```bash
# List connected devices
flutter devices

# Run on a specific device
flutter run -d <device-id>

# Run in release mode
flutter run --release
```

On first launch:
1. Sign up with any email + password (minimum 6 chars)
2. You land on the Instruction screen
3. Tap **PLAY** to start the game
4. Move with A/D or arrow keys; SPACE to shoot
5. When HP reaches 0, enter your email on the Game Over screen

---

## STEP 6 — Deploy Firestore Security Rules

Once you're ready for production, deploy the security rules:

```bash
# Login to Firebase CLI
firebase login

# Deploy only the rules
firebase deploy --only firestore:rules
```

The rules file is at `firestore.rules` in the project root.

---

## STEP 7 — Android Release Build

### Generate keystore (once, keep this file safe!)
```bash
keytool -genkey -v \
  -keystore ~/upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias upload
```

### Create android/key.properties (git-ignored)
```properties
storePassword=YOUR_STORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=upload
storeFile=/Users/YOUR_USERNAME/upload-keystore.jks
```

### Build signed App Bundle
```bash
flutter build appbundle --release
# Output: build/app/outputs/bundle/release/app-release.aab
```

### Upload to Google Play
1. Create developer account at https://play.google.com/console ($25 one-time fee)
2. Create new app → fill in store listing
3. Production → Create release → Upload `.aab` → Review → Rollout

---

## STEP 8 — iOS Release Build (macOS required)

### Prereqs
- Apple Developer account ($99/year) — https://developer.apple.com
- Bundle ID registered in Apple Developer portal
- Xcode 15+ installed

### Build
```bash
flutter build ipa --release
```

### Distribute
```
Xcode → Product → Archive → Distribute App → App Store Connect → Upload
```

Then in App Store Connect:
1. Fill in app metadata, screenshots, privacy policy
2. Select uploaded build → Submit for Review

---

## STEP 9 — CI/CD with GitHub Actions (optional)

1. Push the project to a GitHub repository
2. Add required secrets in **Settings → Secrets and variables → Actions**:
   - `KEYSTORE_BASE64` — `base64 -i ~/upload-keystore.jks | pbcopy`
   - `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
   - `SERVICE_ACCOUNT_JSON` — from Play Console → Setup → API access
   - `GOOGLE_SERVICES_JSON` — contents of `android/app/google-services.json`
   - `APPSTORE_ISSUER_ID`, `APPSTORE_API_KEY_ID`, `APPSTORE_API_KEY`
   - `GOOGLE_SERVICE_INFO_PLIST` — contents of `ios/Runner/GoogleService-Info.plist`
3. Push to `main` → the workflow in `.github/workflows/deploy.yml` runs automatically

---

## Common Errors & Fixes

| Error | Fix |
|-------|-----|
| `No Firebase App '[DEFAULT]'` | `await Firebase.initializeApp()` not called or not awaited in `main()` |
| `MissingPluginException (firebase_auth)` | Run `flutter clean && flutter pub get`, then `cd ios && pod install` |
| `firebase_options.dart not found` | Run `flutterfire configure` to generate it |
| Hitbox collision not working | Add `HasCollisionDetection` mixin to `SpaceGame` and `RectangleHitbox()` to each component |
| Play Store: signing key error | Wrong keystore used — must use same `upload-keystore.jks` as original upload |
| App Store: Missing compliance | Add `ITSAppUsesNonExemptEncryption = NO` to `ios/Runner/Info.plist` |
| `minSdkVersion` error | Set `minSdkVersion 21` in `android/app/build.gradle` |
