// lib/widgets/score_display.dart
//
// ScoreDisplay — reactive score counter shown in the top-right corner.
//
// Uses ValueListenableBuilder so only this widget rebuilds when the score
// changes, not the entire PlayScreen widget tree.

import 'package:flutter/material.dart';

class ScoreDisplay extends StatelessWidget {
  final ValueNotifier<int> scoreNotifier;

  const ScoreDisplay({super.key, required this.scoreNotifier});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: scoreNotifier,
      builder: (_, score, __) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'SCORE',
              style: TextStyle(
                color: Color(0xFF607B9B),
                fontSize: 10,
                letterSpacing: 3,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              // Format with thousands separator for large scores.
              _formatScore(score),
              style: const TextStyle(
                color: Color(0xFF00D4FF),
                fontSize: 22,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ],
        );
      },
    );
  }

  String _formatScore(int score) {
    // Simple thousands separator (e.g. 12345 → "12,345").
    final s = score.toString();
    if (s.length <= 3) return s;
    final buffer = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buffer.write(',');
      buffer.write(s[i]);
    }
    return buffer.toString();
  }
}
