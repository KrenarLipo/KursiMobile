// lib/widgets/hp_bar.dart
//
// HpBar — a reactive HP progress bar widget.
//
// WHY ValueListenableBuilder?
// ---------------------------
//   SpaceGame updates hpNotifier.value directly from Flame's game loop.
//   ValueListenableBuilder subscribes to the notifier and rebuilds only the
//   bar widget (not the full widget tree) on every HP change — efficient and
//   simple with no need for StreamBuilder or setState().
//
// COLOUR CODING
// -------------
//   > 50 % HP  →  green accent  (safe)
//   > 25 % HP  →  orange accent (caution)
//   ≤ 25 % HP  →  red accent    (danger)
//
// The bar width transitions smoothly because it is driven by FractionallySizedBox
// with the fraction equal to hp/100.

import 'package:flutter/material.dart';

class HpBar extends StatelessWidget {
  /// The notifier updated by SpaceGame.applyDamage().
  final ValueNotifier<int> hpNotifier;

  const HpBar({super.key, required this.hpNotifier});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: hpNotifier,
      builder: (_, hp, __) {
        // fraction: 0.0 (empty) → 1.0 (full)
        final fraction = (hp / 100).clamp(0.0, 1.0);

        // Colour shifts based on remaining HP percentage.
        final Color barColor;
        if (fraction > 0.5) {
          barColor = Colors.greenAccent;
        } else if (fraction > 0.25) {
          barColor = Colors.orangeAccent;
        } else {
          barColor = Colors.redAccent;
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── HP number ───────────────────────────────────────────────────
            Text(
              '$hp HP',
              style: TextStyle(
                color: barColor,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 3),

            // ── Bar container ────────────────────────────────────────────────
            Container(
              width:  160,
              height: 10,
              decoration: BoxDecoration(
                // Dark trough
                color:        const Color(0xFF1E3A5F),
                borderRadius: BorderRadius.circular(5),
              ),
              child: FractionallySizedBox(
                alignment:   Alignment.centerLeft,
                widthFactor: fraction,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 120),
                  decoration: BoxDecoration(
                    color:        barColor,
                    borderRadius: BorderRadius.circular(5),
                    // Glow effect at high health
                    boxShadow: fraction > 0.5
                        ? [BoxShadow(
                            color:      barColor.withOpacity(0.5),
                            blurRadius: 4,
                            spreadRadius: 1,
                          )]
                        : null,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
