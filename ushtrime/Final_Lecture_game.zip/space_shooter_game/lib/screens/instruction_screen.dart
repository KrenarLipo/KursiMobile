// lib/screens/instruction_screen.dart
//
// Landing / Tutorial screen — first screen after login.
//
// LAYOUT
// ------
//   • Title logo and game name at the top.
//   • A controls card showing keyboard keys and their actions.
//   • Two large buttons at the bottom:
//       [INSTRUCTIONS]  →  opens a full-screen dialog with more detail.
//       [PLAY]          →  navigates to '/play' (PlayScreen).
//
// The _StarfieldBackground widget draws animated dots that simulate stars;
// it is purely decorative and can be replaced with a static Container.

import 'dart:math' as math;
import 'package:flutter/material.dart';

class InstructionScreen extends StatelessWidget {
  const InstructionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        const _StarfieldBackground(),
        SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // ── Title ─────────────────────────────────────────────────
                  const Text('🚀',  style: TextStyle(fontSize: 56)),
                  const SizedBox(height: 12),
                  const Text(
                    'SPACE SHOOTER',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF00D4FF),
                      letterSpacing: 6,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Survive as long as you can!',
                    style: TextStyle(color: Color(0xFFB8C9E0), fontSize: 14),
                  ),
                  const SizedBox(height: 40),

                  // ── Controls Card ─────────────────────────────────────────
                  Container(
                    constraints: const BoxConstraints(maxWidth: 420),
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0D1526),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: const Color(0xFF00D4FF).withOpacity(0.3)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '🎮  Controls',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF00D4FF),
                          ),
                        ),
                        const SizedBox(height: 16),
                        ..._controls.map((c) => _ControlRow(
                          keys:   c[0],
                          action: c[1],
                        )),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // ── Game Rules Card ───────────────────────────────────────
                  Container(
                    constraints: const BoxConstraints(maxWidth: 420),
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0D1526),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: const Color(0xFF9B30F5).withOpacity(0.3)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '📋  Rules',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF9B30F5),
                          ),
                        ),
                        const SizedBox(height: 12),
                        ..._rules.map((r) => Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('▸ ',
                                style: TextStyle(
                                  color: Color(0xFF9B30F5), fontSize: 13)),
                              Expanded(
                                child: Text(r,
                                  style: const TextStyle(
                                    color: Color(0xFFB8C9E0), fontSize: 13)),
                              ),
                            ],
                          ),
                        )),
                      ],
                    ),
                  ),
                  const SizedBox(height: 40),

                  // ── Buttons ───────────────────────────────────────────────
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 420),
                    child: Row(
                      children: [
                        // INSTRUCTIONS dialog
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => showDialog(
                              context: context,
                              builder: (_) => const _FullControlsDialog()),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF00D4FF),
                              side: const BorderSide(color: Color(0xFF00D4FF)),
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            ),
                            child: const Text('INSTRUCTIONS',
                              style: TextStyle(
                                letterSpacing: 2, fontWeight: FontWeight.bold)),
                          ),
                        ),
                        const SizedBox(width: 16),
                        // PLAY button
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () =>
                              Navigator.pushReplacementNamed(context, '/play'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF00D4FF),
                              foregroundColor: const Color(0xFF080C18),
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            ),
                            child: const Text('▶  PLAY',
                              style: TextStyle(
                                fontSize: 16,
                                letterSpacing: 3,
                                fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ]),
    );
  }
}

// ── Control rows data ─────────────────────────────────────────────────────────
const _controls = [
  ['←  →   or   A  D',    'Move spaceship left / right'],
  ['↑   or   W',           'Accelerate / thrust forward'],
  ['SPACE  or  Tap  🔥',   'Fire bullet'],
  ['ESC',                   'Pause the game'],
];

const _rules = [
  'Destroy enemies before they reach the bottom of the screen.',
  'Small enemy (◆) hits you for 15 HP.  Large enemy (◈) hits for 20 HP.',
  'Enemy speed increases every 10 seconds — stay alert!',
  'Your HP bar turns red as your health drops. When it hits 0 — Game Over.',
  'On Game Over enter your email to save your score. Each email is unique.',
];

// ── Control Row widget ────────────────────────────────────────────────────────
class _ControlRow extends StatelessWidget {
  final String keys;
  final String action;
  const _ControlRow({required this.keys, required this.action});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: const Color(0xFF00D4FF).withOpacity(0.1),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: const Color(0xFF00D4FF).withOpacity(0.4)),
          ),
          child: Text(keys,
            style: const TextStyle(
              fontFamily: 'monospace',
              color: Color(0xFF00D4FF),
              fontSize: 12,
              fontWeight: FontWeight.bold,
            )),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(action,
            style: const TextStyle(
              color: Color(0xFFB8C9E0), fontSize: 13)),
        ),
      ]),
    );
  }
}

// ── Full Controls Dialog ──────────────────────────────────────────────────────
class _FullControlsDialog extends StatelessWidget {
  const _FullControlsDialog();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF0D1526),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Full Controls Guide',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF00D4FF),
              )),
            const SizedBox(height: 20),
            ..._controls.map((c) => _ControlRow(keys: c[0], action: c[1])),
            const Divider(color: Color(0xFF1E3A5F), height: 24),
            const Text('Mobile Touch Controls',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Color(0xFF9B30F5),
              )),
            const SizedBox(height: 8),
            const Text(
              '◀  ▶  buttons on the bottom-left to move left/right.\n'
              '🔥  button on the bottom-right to shoot.\n'
              'Controls appear automatically on touch devices.',
              style: TextStyle(color: Color(0xFFB8C9E0), fontSize: 13),
            ),
            const SizedBox(height: 20),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('CLOSE',
                  style: TextStyle(
                    color: Color(0xFF00D4FF), letterSpacing: 2)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Starfield background ──────────────────────────────────────────────────────
// Simple static star dots rendered with CustomPaint.
// For an animated version add a TickerProviderStateMixin and offset each
// star's y by a small amount each frame.
class _StarfieldBackground extends StatelessWidget {
  const _StarfieldBackground();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _StarPainter(),
      child: const SizedBox.expand(),
    );
  }
}

class _StarPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random(42); // fixed seed for stable star positions
    final paint = Paint()..color = Colors.white.withOpacity(0.6);
    for (var i = 0; i < 120; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height;
      final r = rng.nextDouble() * 1.5 + 0.3;
      canvas.drawCircle(Offset(x, y), r, paint);
    }
    // Background fill
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..color = const Color(0xFF080C18),
    );
    // Redraw stars on top of fill
    for (var i = 0; i < 120; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height;
      final r = rng.nextDouble() * 1.5 + 0.3;
      canvas.drawCircle(Offset(x, y), r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
