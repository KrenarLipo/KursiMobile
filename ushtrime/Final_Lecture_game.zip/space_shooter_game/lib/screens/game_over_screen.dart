// lib/screens/game_over_screen.dart
//
// Shown when the player's HP reaches 0.
//
// FLOW
// ----
//   1. Display "GAME OVER" + the player's final score (passed as route argument).
//   2. Show an email text field.
//   3. On submission:
//        a. Validate the email format.
//        b. Check Firestore for duplicates via ScoreService.emailExists().
//        c. If new → save via ScoreService.saveScore() → show "Play Again" button.
//        d. If duplicate → show error, stay on the form.
//   4. "PLAY AGAIN" navigates to '/play' (a fresh PlayScreen and SpaceGame).
//   5. "BACK TO MENU" navigates to '/' (InstructionScreen).
//
// The score is passed via ModalRoute.settings.arguments as an int.

import 'package:flutter/material.dart';
import '../services/score_service.dart';

class GameOverScreen extends StatefulWidget {
  const GameOverScreen({super.key});

  @override
  State<GameOverScreen> createState() => _GameOverScreenState();
}

class _GameOverScreenState extends State<GameOverScreen> {
  final _emailCtrl = TextEditingController();
  final _formKey   = GlobalKey<FormState>();

  bool    _isSubmitting = false;
  bool    _submitted    = false;   // true after a successful save
  String? _errorMessage;

  // ── Submit email + score ───────────────────────────────────────────────────
  Future<void> _submit(int score) async {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();

    setState(() {
      _isSubmitting = true;
      _errorMessage = null;
    });

    final email = _emailCtrl.text.trim().toLowerCase();

    try {
      // Guard: reject duplicate emails
      final alreadyExists = await ScoreService.emailExists(email);
      if (alreadyExists) {
        setState(() => _errorMessage =
          'This email has already been used. Try a different one.');
        return;
      }

      // Persist to Firestore
      await ScoreService.saveScore(email: email, score: score);

      setState(() => _submitted = true);
    } catch (e) {
      setState(() => _errorMessage = 'Failed to save score: $e');
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    // The score is passed as a route argument from PlayScreen.
    final score = (ModalRoute.of(context)?.settings.arguments as int?) ?? 0;

    return Scaffold(
      backgroundColor: const Color(0xFF080C18),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 400),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // ── Game Over heading ────────────────────────────────────────
                const Text('💀', style: TextStyle(fontSize: 64)),
                const SizedBox(height: 12),
                const Text(
                  'GAME OVER',
                  style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFFF3A5E),
                    letterSpacing: 6,
                  ),
                ),
                const SizedBox(height: 12),

                // ── Score display ────────────────────────────────────────────
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0D1526),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: const Color(0xFF00D4FF).withOpacity(0.4)),
                  ),
                  child: RichText(
                    text: TextSpan(children: [
                      const TextSpan(
                        text: 'Score  ',
                        style: TextStyle(
                          color: Color(0xFFB8C9E0), fontSize: 16)),
                      TextSpan(
                        text: '$score',
                        style: const TextStyle(
                          color: Color(0xFF00D4FF),
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        )),
                    ]),
                  ),
                ),
                const SizedBox(height: 32),

                // ── Email form or success state ──────────────────────────────
                if (!_submitted) ...[
                  const Text(
                    'Enter your email to save your score',
                    style: TextStyle(
                      color: Color(0xFFB8C9E0), fontSize: 14),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  Form(
                    key: _formKey,
                    child: TextFormField(
                      controller:  _emailCtrl,
                      keyboardType: TextInputType.emailAddress,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'your@email.com',
                        hintStyle: const TextStyle(color: Color(0xFF607B9B)),
                        prefixIcon: const Icon(Icons.email_outlined,
                          color: Color(0xFF00D4FF), size: 20),
                        filled:    true,
                        fillColor: const Color(0xFF0D1526),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                            color: Color(0xFF1E3A5F))),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                            color: Color(0xFF1E3A5F))),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                            color: Color(0xFF00D4FF), width: 1.5)),
                      ),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) {
                          return 'Email is required';
                        }
                        if (!v.contains('@') || !v.contains('.')) {
                          return 'Enter a valid email address';
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Error message
                  if (_errorMessage != null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF3A5E).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: const Color(0xFFFF3A5E).withOpacity(0.4)),
                      ),
                      child: Text(
                        _errorMessage!,
                        style: const TextStyle(
                          color: Color(0xFFFF3A5E), fontSize: 13),
                      ),
                    ),
                  const SizedBox(height: 16),

                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isSubmitting ? null : () => _submit(score),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF00D4FF),
                        foregroundColor: const Color(0xFF080C18),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                        textStyle: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                      child: _isSubmitting
                          ? const SizedBox(
                              width: 20, height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: Color(0xFF080C18)))
                          : const Text('SAVE SCORE'),
                    ),
                  ),
                ] else ...[
                  // ── Post-submission state ──────────────────────────────────
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF00FF88).withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFF00FF88).withOpacity(0.3)),
                    ),
                    child: const Row(children: [
                      Icon(Icons.check_circle_outline,
                        color: Color(0xFF00FF88)),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Score saved!  Great run.',
                          style: TextStyle(
                            color: Color(0xFF00FF88),
                            fontWeight: FontWeight.bold,
                          )),
                      ),
                    ]),
                  ),
                ],

                const SizedBox(height: 28),
                const Divider(color: Color(0xFF1E3A5F)),
                const SizedBox(height: 20),

                // ── Navigation buttons ──────────────────────────────────────
                Row(children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () =>
                        Navigator.pushReplacementNamed(context, '/'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFFB8C9E0),
                        side: const BorderSide(color: Color(0xFF1E3A5F)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('⬅  MENU',
                        style: TextStyle(letterSpacing: 1)),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () =>
                        Navigator.pushReplacementNamed(context, '/play'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF9B30F5),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                        textStyle: const TextStyle(
                          fontWeight: FontWeight.bold, letterSpacing: 2),
                      ),
                      child: const Text('▶  PLAY AGAIN'),
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }
}
