// lib/screens/login_screen.dart
//
// Login / Register screen.
// This screen is the app's initial route ('/login').
//
// FLOW
// ----
//   • The screen starts in "Sign In" mode.
//   • A TextButton at the bottom toggles to "Register" mode (and back).
//   • On success in either mode, the user is navigated to '/' (InstructionScreen).
//   • On error, the Firebase-friendly error string is shown in red below the form.
//
// FIREBASE USAGE
// ---------------
//   Delegates all Firebase calls to AuthService (lib/services/auth_service.dart).
//   This screen contains only UI logic; no direct FirebaseAuth calls here.

import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // ── State ──────────────────────────────────────────────────────────────────
  final _emailCtrl    = TextEditingController();
  final _passCtrl     = TextEditingController();
  final _formKey      = GlobalKey<FormState>();
  bool  _isLoginMode  = true;   // toggles between Sign In and Register UI
  bool  _isLoading    = false;
  String? _errorMessage;

  // ── Submit handler ─────────────────────────────────────────────────────────
  Future<void> _submit() async {
    // Dismiss keyboard
    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading    = true;
      _errorMessage = null;
    });

    try {
      if (_isLoginMode) {
        await AuthService.signIn(
          email:    _emailCtrl.text.trim(),
          password: _passCtrl.text.trim(),
        );
      } else {
        await AuthService.register(
          email:    _emailCtrl.text.trim(),
          password: _passCtrl.text.trim(),
        );
      }
      // Navigate to instruction screen on success.
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/');
      }
    } catch (e) {
      setState(() => _errorMessage = e.toString());
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  void _toggleMode() {
    setState(() {
      _isLoginMode  = !_isLoginMode;
      _errorMessage = null;
      _emailCtrl.clear();
      _passCtrl.clear();
    });
  }

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        // Simple starfield-style gradient background
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF080C18), Color(0xFF0D1526), Color(0xFF080C18)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),

        Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 380),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // ── Logo / Icon ──────────────────────────────────────────
                    const Text('🚀', style: TextStyle(fontSize: 64)),
                    const SizedBox(height: 12),
                    Text(
                      _isLoginMode ? 'SIGN IN' : 'REGISTER',
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF00D4FF),
                        letterSpacing: 6,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _isLoginMode
                          ? 'Sign in to save your scores'
                          : 'Create an account to track your best runs',
                      style: const TextStyle(
                        color: Color(0xFFB8C9E0),
                        fontSize: 13,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 40),

                    // ── Email Field ──────────────────────────────────────────
                    _InputField(
                      controller: _emailCtrl,
                      hint:      'Email address',
                      icon:       Icons.email_outlined,
                      keyboardType: TextInputType.emailAddress,
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Email is required';
                        if (!v.contains('@')) return 'Enter a valid email';
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    // ── Password Field ───────────────────────────────────────
                    _InputField(
                      controller: _passCtrl,
                      hint:       'Password',
                      icon:       Icons.lock_outline,
                      obscure:    true,
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Password is required';
                        if (!_isLoginMode && v.length < 6) {
                          return 'Password must be at least 6 characters';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),

                    // ── Error Message ────────────────────────────────────────
                    if (_errorMessage != null) ...[
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF3A5E).withOpacity(0.12),
                          border: Border.all(
                            color: const Color(0xFFFF3A5E).withOpacity(0.4)),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(children: [
                          const Icon(Icons.error_outline,
                            color: Color(0xFFFF3A5E), size: 16),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _errorMessage!,
                              style: const TextStyle(
                                color: Color(0xFFFF3A5E), fontSize: 13),
                            ),
                          ),
                        ]),
                      ),
                      const SizedBox(height: 12),
                    ],

                    // ── Submit Button ────────────────────────────────────────
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _submit,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF00D4FF),
                          foregroundColor: const Color(0xFF080C18),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                          textStyle: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                width: 20, height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.5,
                                  color: Color(0xFF080C18)))
                            : Text(_isLoginMode ? 'SIGN IN' : 'REGISTER'),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // ── Toggle Mode ──────────────────────────────────────────
                    TextButton(
                      onPressed: _toggleMode,
                      child: Text(
                        _isLoginMode
                            ? "Don't have an account?  Register"
                            : 'Already have an account?  Sign In',
                        style: const TextStyle(
                          color: Color(0xFF9B30F5), fontSize: 13),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }
}

// ── Reusable styled input field ───────────────────────────────────────────────
class _InputField extends StatelessWidget {
  final TextEditingController  controller;
  final String                 hint;
  final IconData               icon;
  final bool                   obscure;
  final TextInputType?         keyboardType;
  final String? Function(String?)? validator;

  const _InputField({
    required this.controller,
    required this.hint,
    required this.icon,
    this.obscure     = false,
    this.keyboardType,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller:  controller,
      obscureText: obscure,
      keyboardType: keyboardType,
      validator:   validator,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Color(0xFF607B9B)),
        prefixIcon: Icon(icon, color: const Color(0xFF00D4FF), size: 20),
        filled:    true,
        fillColor: const Color(0xFF0D1526),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF1E3A5F)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF1E3A5F)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF00D4FF), width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFFF3A5E)),
        ),
      ),
    );
  }
}
