// lib/screens/play_screen.dart
//
// PlayScreen — the host widget for the actual game.
//
// RESPONSIBILITIES
// ----------------
//   1. Creates a SpaceGame instance and wraps it in Flame's GameWidget.
//   2. Overlays the HP bar and score counter on top of the game canvas.
//   3. Overlays the mobile D-pad for touch devices.
//   4. Listens to SpaceGame.hpNotifier; when HP reaches 0 navigates to
//      '/gameover' and passes the final score as a route argument.
//
// WHY ValueNotifier?
// ------------------
//   Flame's update loop runs on a separate isolate-like tick.  To bridge
//   game state into Flutter widgets we use ValueNotifier<int> which is
//   safe to read from the widget tree via ValueListenableBuilder.

import 'package:flutter/material.dart';
import 'package:flame/game.dart';

import '../game/space_game.dart';
import '../widgets/hp_bar.dart';
import '../widgets/score_display.dart';

class PlayScreen extends StatefulWidget {
  const PlayScreen({super.key});

  @override
  State<PlayScreen> createState() => _PlayScreenState();
}

class _PlayScreenState extends State<PlayScreen> {
  late final SpaceGame _game;

  @override
  void initState() {
    super.initState();
    _game = SpaceGame();

    // Listen for HP reaching 0 and navigate to the game-over screen.
    // The listener is added here (not in SpaceGame) so we have access to
    // the BuildContext for Navigator.
    _game.hpNotifier.addListener(_onHpChanged);
  }

  void _onHpChanged() {
    if (_game.hpNotifier.value <= 0) {
      // Remove listener before navigating to avoid duplicate calls.
      _game.hpNotifier.removeListener(_onHpChanged);

      // Small delay so the game-over visual state is visible for a frame.
      Future.microtask(() {
        if (mounted) {
          Navigator.pushReplacementNamed(
            context,
            '/gameover',
            // Pass the score so GameOverScreen can display it.
            arguments: _game.score,
          );
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080C18),
      body: Stack(children: [
        // ── Flame game canvas ──────────────────────────────────────────────
        GameWidget(game: _game),

        // ── HP bar — top left ──────────────────────────────────────────────
        Positioned(
          top: 48,
          left: 16,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('HP',
                style: TextStyle(
                  color: Color(0xFF00D4FF),
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
              const SizedBox(height: 4),
              HpBar(hpNotifier: _game.hpNotifier),
            ],
          ),
        ),

        // ── Score — top right ──────────────────────────────────────────────
        Positioned(
          top: 44,
          right: 16,
          child: ScoreDisplay(scoreNotifier: _game.scoreNotifier),
        ),

        // ── Mobile D-pad overlay ───────────────────────────────────────────
        Positioned(
          bottom: 28,
          left: 0,
          right: 0,
          child: _MobileDpad(game: _game),
        ),
      ]),
    );
  }

  @override
  void dispose() {
    _game.hpNotifier.removeListener(_onHpChanged);
    super.dispose();
  }
}

// ── Mobile on-screen controls ─────────────────────────────────────────────────
//
// Only shown on touch devices.  Uses kIsWeb / Platform checks to hide on desktop.
// For simplicity we always render the D-pad.  On desktop keyboard input handles
// movement, but the buttons are still tap-able.
class _MobileDpad extends StatelessWidget {
  final SpaceGame game;
  const _MobileDpad({required this.game});

  Widget _btn(String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width:  60,
        height: 60,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          border: Border.all(
            color: const Color(0xFF00D4FF).withOpacity(0.6), width: 1.5),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Center(
          child: Text(label,
            style: const TextStyle(color: Colors.white, fontSize: 22)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Left / Right movement buttons
          Row(children: [
            _btn('◀', () => game.player.moveLeft()),
            const SizedBox(width: 12),
            _btn('▶', () => game.player.moveRight()),
          ]),
          // Fire button
          _btn('🔥', () => game.player.shootBullet()),
        ],
      ),
    );
  }
}
