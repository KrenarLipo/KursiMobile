// lib/services/score_service.dart
//
// ScoreService — Firestore persistence for player scores.
//
// COLLECTION SCHEMA
// -----------------
//   Collection : scores
//   Document   : auto-ID
//   Fields:
//     email      (String)    — player's unique email (lowercase)
//     score      (int)       — final score at game over
//     createdAt  (Timestamp) — server-side timestamp set on write
//
// METHODS
// -------
//   saveScore(email, score)  →  creates a new document in 'scores'.
//   emailExists(email)       →  returns true if the email is already in 'scores'.
//   getTopScores(limit)      →  returns the top [limit] scores ordered by score.
//   getScoreForEmail(email)  →  returns the score for a specific email (or null).
//
// DUPLICATE GUARD
// ---------------
//   emailExists() is called from GameOverScreen before saveScore().
//   The check is a Firestore query, not enforced by a security rule, so it's
//   possible (in a race condition) for two documents with the same email to be
//   written.  For a production app add a Firestore rule or use the email as the
//   document ID to guarantee uniqueness at the database level.
//
// FIRESTORE SECURITY RULES (copy to Firebase Console → Firestore → Rules)
// -------------------------
//   rules_version = '2';
//   service cloud.firestore {
//     match /databases/{database}/documents {
//       match /scores/{docId} {
//         allow read:   if true;
//         allow create: if request.auth != null
//                       && request.resource.data.keys()
//                          .hasAll(['email','score','createdAt'])
//                       && request.resource.data.score is int
//                       && request.resource.data.score >= 0;
//         allow update, delete: if false;
//       }
//     }
//   }

import 'package:cloud_firestore/cloud_firestore.dart';

class ScoreService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// Firestore collection name.
  static const String _collection = 'scores';

  // ── Save a score ──────────────────────────────────────────────────────────

  /// Writes a new score document to Firestore.
  /// Normalises [email] to lowercase for consistent deduplication.
  static Future<void> saveScore({
    required String email,
    required int    score,
  }) async {
    await _db.collection(_collection).add({
      'email':     email.trim().toLowerCase(),
      'score':     score,
      // FieldValue.serverTimestamp() is set by the Firestore server, so it's
      // immune to incorrect client clocks and works across time zones.
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // ── Check for duplicate email ─────────────────────────────────────────────

  /// Returns [true] if [email] is already present in the scores collection.
  /// Uses a limit(1) query for efficiency — we only need to know if at least
  /// one document exists, not how many.
  static Future<bool> emailExists(String email) async {
    final query = await _db
        .collection(_collection)
        .where('email', isEqualTo: email.trim().toLowerCase())
        .limit(1)
        .get();
    return query.docs.isNotEmpty;
  }

  // ── Top scores leaderboard ────────────────────────────────────────────────

  /// Returns up to [limit] score records ordered by score descending.
  /// Each record is a Map with keys: 'email' (String) and 'score' (int).
  static Future<List<Map<String, dynamic>>> getTopScores({
    int limit = 10,
  }) async {
    final snapshot = await _db
        .collection(_collection)
        .orderBy('score', descending: true)
        .limit(limit)
        .get();

    return snapshot.docs.map((doc) => {
      'email': doc['email'] as String,
      'score': doc['score'] as int,
    }).toList();
  }

  // ── Score for a specific email ────────────────────────────────────────────

  /// Returns the score for [email], or null if the email has no record.
  static Future<int?> getScoreForEmail(String email) async {
    final query = await _db
        .collection(_collection)
        .where('email', isEqualTo: email.trim().toLowerCase())
        .limit(1)
        .get();

    if (query.docs.isEmpty) return null;
    return query.docs.first['score'] as int;
  }
}
