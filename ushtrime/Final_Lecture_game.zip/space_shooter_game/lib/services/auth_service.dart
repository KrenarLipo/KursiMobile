// lib/services/auth_service.dart
//
// AuthService — thin wrapper around FirebaseAuth.
//
// WHY A SERVICE CLASS?
// --------------------
//   Keeping all Firebase calls in one place means:
//     • Screens never import firebase_auth directly.
//     • Error codes are converted to friendly strings in one place.
//     • Easy to swap the implementation in tests
//       (inject a FakeFirebaseAuth instead of the real one).
//
// METHODS
// -------
//   register(email, password)  →  creates a new Firebase Auth account.
//   signIn(email, password)    →  signs in an existing account.
//   signOut()                  →  signs out the current user.
//   currentUser                →  returns the currently signed-in User or null.
//
// ERROR HANDLING
// --------------
//   FirebaseAuthException.code strings are mapped to human-readable messages.
//   The mapped message is re-thrown so the calling screen can display it.
//
// USAGE EXAMPLE
// -------------
//   try {
//     await AuthService.signIn(email: 'test@example.com', password: 's3cr3t');
//     Navigator.pushReplacementNamed(context, '/');
//   } catch (e) {
//     setState(() => errorMessage = e.toString());
//   }

import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  // Use the singleton FirebaseAuth instance.
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  // ── Register (create account) ─────────────────────────────────────────────

  /// Creates a new Firebase Auth user with [email] and [password].
  /// Throws a friendly String on failure.
  static Future<UserCredential> register({
    required String email,
    required String password,
  }) async {
    try {
      return await _auth.createUserWithEmailAndPassword(
        email:    email.trim(),
        password: password.trim(),
      );
    } on FirebaseAuthException catch (e) {
      throw _friendlyMessage(e.code);
    }
  }

  // ── Sign In ───────────────────────────────────────────────────────────────

  /// Signs in an existing user with [email] and [password].
  /// Throws a friendly String on failure.
  static Future<UserCredential> signIn({
    required String email,
    required String password,
  }) async {
    try {
      return await _auth.signInWithEmailAndPassword(
        email:    email.trim(),
        password: password.trim(),
      );
    } on FirebaseAuthException catch (e) {
      throw _friendlyMessage(e.code);
    }
  }

  // ── Sign Out ──────────────────────────────────────────────────────────────

  /// Signs out the current user from Firebase Auth.
  static Future<void> signOut() => _auth.signOut();

  // ── Current User ──────────────────────────────────────────────────────────

  /// Returns the currently signed-in [User], or null if nobody is signed in.
  static User? get currentUser => _auth.currentUser;

  /// Stream of authentication state changes.
  /// Useful for showing a loading gate while the app checks auth on startup.
  static Stream<User?> get authStateChanges => _auth.authStateChanges();

  // ── Error code mapper ─────────────────────────────────────────────────────

  /// Converts a FirebaseAuth error code to a user-friendly message.
  static String _friendlyMessage(String code) {
    return switch (code) {
      'email-already-in-use'   => 'An account with this email already exists.',
      'invalid-email'          => 'Please enter a valid email address.',
      'weak-password'          => 'Password must be at least 6 characters.',
      'user-not-found'         => 'No account found for this email.',
      'wrong-password'         => 'Incorrect password. Please try again.',
      'user-disabled'          => 'This account has been disabled.',
      'too-many-requests'      => 'Too many failed attempts. Try again later.',
      'operation-not-allowed'  => 'Email/password sign-in is not enabled.',
      'network-request-failed' => 'Network error. Check your connection.',
      _                        => 'Authentication error ($code).',
    };
  }
}
