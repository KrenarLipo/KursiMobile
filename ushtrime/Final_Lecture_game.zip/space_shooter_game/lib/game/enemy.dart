// lib/game/enemy.dart
//
// Enemy — a single enemy ship component.
//
// TWO TYPES
// ---------
//   EnemyType.small  →  40×40 sprite,  −15 HP on collision,  +10 score on kill.
//   EnemyType.large  →  64×64 sprite,  −20 HP on collision,  +25 score on kill.
//
// MOVEMENT
// --------
//   Moves straight down at [speed] pixels/second.
//   speed is set by EnemySpawner and increases every 10 s.
//
// COLLISION
// ---------
//   • Collides with Player → deals damage to SpaceGame, then removes itself.
//   • Collides with Bullet → Bullet awards score and removes both itself and
//     the enemy (Bullet.onCollisionStart handles that case).
//   • Leaves the screen    → removes itself silently (off-screen cleanup).
//
// OFF-SCREEN CLEANUP
// ------------------
//   We check position.y > screenHeight + size.y in update() rather than
//   relying on ScreenHitbox collision because enemies start above the screen
//   (negative y) and must not be removed on spawn.

import 'dart:async';

import 'package:flame/collisions.dart';
import 'package:flame/components.dart';

import 'space_game.dart';
import 'player.dart';

/// Distinguishes small (fast, weak) from large (slow, tough) enemies.
enum EnemyType { small, large }

class Enemy extends SpriteComponent
    with HasGameRef<SpaceGame>, CollisionCallbacks {

  final EnemyType type;

  /// Pixels per second — set by EnemySpawner, escalates over time.
  double speed;

  Enemy({
    required this.type,
    required this.speed,
    required Vector2 position,
  }) : super(position: position);

  // ── Damage and score values per type ──────────────────────────────────────
  int get _damage => type == EnemyType.small ? 15 : 20;
  int get _score  => type == EnemyType.small ? 10 : 25;

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    // Choose sprite and size by type.
    final spriteName = type == EnemyType.small
        ? 'enemy_small.png'
        : 'enemy_large.png';

    try {
      sprite = await gameRef.loadSprite(spriteName);
    } catch (_) {
      // No asset: fallback to invisible rectangle (hitbox still works).
    }

    size   = type == EnemyType.small ? Vector2(40, 40) : Vector2(64, 64);
    anchor = Anchor.center;

    add(RectangleHitbox());
  }

  @override
  void update(double dt) {
    super.update(dt);

    // Move downward at the current speed.
    position.y += speed * dt;

    // Remove once fully off the bottom of the virtual screen.
    final screenHeight = gameRef.camera.visibleWorldRect.height;
    if (position.y > screenHeight + size.y) {
      removeFromParent();
    }
  }

  @override
  void onCollisionStart(
    Set<Vector2> intersectionPoints,
    PositionComponent other,
  ) {
    super.onCollisionStart(intersectionPoints, other);

    // Only handle Player collision here.
    // Bullet collision is handled inside Bullet.onCollisionStart so that
    // the bullet can award the score before both are removed.
    if (other is Player) {
      gameRef.applyDamage(_damage);
      removeFromParent();
    }
  }
}
