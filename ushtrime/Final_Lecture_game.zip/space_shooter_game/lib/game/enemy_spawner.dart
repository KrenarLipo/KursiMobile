// lib/game/enemy_spawner.dart
//
// EnemySpawner — timed enemy factory with speed escalation.
//
// HOW IT WORKS
// ------------
//   This component has no visual representation.  It only overrides update(dt)
//   to maintain two independent timers:
//
//   _spawnTimer   → counts up to _spawnRate, then spawns one enemy and resets.
//   _speedTimer   → counts up to 10 seconds.  On every 10-second mark:
//                     • _enemySpeed is increased by 25 px/s.
//                     • _spawnRate is decreased by 0.1 s (enemies spawn faster).
//                     • _spawnRate is clamped to a minimum of 0.4 s so the game
//                       doesn't become physically impossible.
//
// SPAWN POSITION
// --------------
//   Enemies start just above the top of the screen (y = -40) at a random
//   horizontal position within the screen width (accounting for enemy size).
//
// ENEMY DISTRIBUTION
// ------------------
//   50 % small, 50 % large (random coin-flip each spawn).
//   You can adjust this ratio by changing the probability in _spawnEnemy().

import 'dart:math' as math;

import 'package:flame/components.dart';

import 'space_game.dart';
import 'enemy.dart';

class EnemySpawner extends Component with HasGameRef<SpaceGame> {

  // ── Spawn timing ──────────────────────────────────────────────────────────
  double _spawnTimer = 0;
  double _spawnRate  = 1.5; // seconds between enemy spawns (decreases over time)

  // ── Speed escalation ──────────────────────────────────────────────────────
  double _speedTimer  = 0;
  double _enemySpeed  = 100; // starting enemy speed in px/s

  final math.Random _rng = math.Random();

  @override
  void update(double dt) {
    super.update(dt);

    if (gameRef.isGameOver) return;

    // ── Spawn timer ──────────────────────────────────────────────────────────
    _spawnTimer += dt;
    if (_spawnTimer >= _spawnRate) {
      _spawnTimer = 0;
      _spawnEnemy();
    }

    // ── Speed escalation timer (every 10 seconds) ────────────────────────────
    _speedTimer += dt;
    if (_speedTimer >= 10.0) {
      _speedTimer = 0;

      // Increase enemy speed by 25 px/s each interval.
      _enemySpeed += 25;

      // Decrease spawn interval (but no faster than 0.4 s apart).
      _spawnRate = (_spawnRate - 0.1).clamp(0.4, double.infinity);

      // Optional: log to console during development.
      // ignore: avoid_print
      print('[EnemySpawner] Speed: $_enemySpeed px/s  |  '
            'Rate: ${_spawnRate.toStringAsFixed(2)} s');
    }
  }

  // ── Spawn a single enemy ──────────────────────────────────────────────────
  void _spawnEnemy() {
    final screenWidth = gameRef.camera.visibleWorldRect.width;

    // Coin-flip: 50% small, 50% large.
    final type = _rng.nextBool() ? EnemyType.small : EnemyType.large;

    // Maximum enemy width is 64 (large); ensure it doesn't spawn off-screen.
    const maxEnemyHalfW = 32.0;
    final x = maxEnemyHalfW +
        _rng.nextDouble() * (screenWidth - maxEnemyHalfW * 2);

    gameRef.add(Enemy(
      type:     type,
      speed:    _enemySpeed,
      position: Vector2(x, -40), // start above the visible area
    ));
  }
}
