// lib/game/bullet.dart
//
// Bullet — a single projectile fired by the Player.
//
// MOVEMENT
// --------
//   Travels straight up at 400 px/s.
//   Removed when it exits the top of the screen (y < -size.y).
//
// COLLISION
// ---------
//   Collides with Enemy → awards score to SpaceGame, then removes both the
//   enemy and this bullet.
//
// SCORING
// -------
//   Score is awarded here (in the Bullet's collision handler) rather than
//   in Enemy because the bullet "earns" the points on impact.
//     small enemy → +10 pts
//     large enemy → +25 pts

import 'dart:async';

import 'package:flame/collisions.dart';
import 'package:flame/components.dart';

import 'space_game.dart';
import 'enemy.dart';

class Bullet extends SpriteComponent
    with HasGameRef<SpaceGame>, CollisionCallbacks {

  static const double _speed = 400; // pixels per second (upward)

  Bullet({required Vector2 startPosition})
      : super(position: startPosition);

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    try {
      sprite = await gameRef.loadSprite('bullet.png');
    } catch (_) {
      // Asset missing: bullet is invisible but still collides.
    }

    size   = Vector2(10, 28);
    anchor = Anchor.center;

    add(RectangleHitbox());
  }

  @override
  void update(double dt) {
    super.update(dt);

    position.y -= _speed * dt; // move upward

    // Off-screen (exited top): remove cleanly.
    if (position.y < -size.y) {
      removeFromParent();
    }
  }

  @override
  void onCollisionStart(
    Set<Vector2> intersectionPoints,
    PositionComponent other,
  ) {
    super.onCollisionStart(intersectionPoints, other);

    if (other is Enemy) {
      // Award score based on the enemy type before removing both.
      final pts = other.type == EnemyType.small ? 10 : 25;
      gameRef.addScore(pts);

      other.removeFromParent();
      removeFromParent();
    }
  }
}
