// lib/game/player.dart
//
// Player — the player's spaceship component.
//
// INPUTS HANDLED
// --------------
//   Keyboard  → arrow keys / WASD for movement, SPACE to shoot.
//   Touch     → PlayScreen's D-pad calls moveLeft(), moveRight(), shootBullet()
//               directly on this component (method references).
//
// MOVEMENT
// --------
//   Horizontal only (left / right).  The ship is clamped to the screen edges
//   so it can never leave the visible area.
//   Speed is constant at 220 px/s.  Increase for a snappier feel.
//
// SHOOTING
// --------
//   Each call to shootBullet() adds one Bullet to the game world.
//   An auto-fire timer (0.35 s) is active while SPACE is held on desktop,
//   but on mobile the user taps the 🔥 button manually.
//
// COLLISION
// ---------
//   Handled in Enemy.onCollisionStart() — the enemy deals damage to
//   SpaceGame when it collides with the Player.  The Player itself does
//   not handle collision logic.

import 'dart:async';

import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/services.dart';

import 'space_game.dart';
import 'bullet.dart';

class Player extends SpriteComponent
    with HasGameRef<SpaceGame>, CollisionCallbacks, KeyboardHandler {

  static const double _speed          = 220; // horizontal pixels per second
  static const double _autoFireRate   = 0.35; // seconds between auto-fire ticks

  final Set<LogicalKeyboardKey> _keysHeld = {};
  double _autoFireTimer = 0;
  bool   _spaceHeld     = false;

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    // Load player sprite.  If the asset is missing Flame will throw; replace
    // 'player_ship.png' with a real sprite (see assets/ folder notes).
    try {
      sprite = await gameRef.loadSprite('player_ship.png');
    } catch (_) {
      // Fallback: white rectangle so the game runs without assets.
    }

    size   = Vector2(60, 80);
    anchor = Anchor.center;

    // Start at the bottom-centre of the virtual screen.
    position = Vector2(
      gameRef.camera.visibleWorldRect.width  / 2,
      gameRef.camera.visibleWorldRect.height - 80,
    );

    // Hitbox for collision with enemies.
    // Slightly inset from the visual sprite to give forgiving hit detection.
    add(RectangleHitbox(
      size:     Vector2(50, 70),
      position: Vector2(5, 5),
    ));
  }

  @override
  void update(double dt) {
    super.update(dt);

    // ── Horizontal movement ──────────────────────────────────────────────────
    if (_keysHeld.contains(LogicalKeyboardKey.arrowLeft) ||
        _keysHeld.contains(LogicalKeyboardKey.keyA)) {
      position.x -= _speed * dt;
    }
    if (_keysHeld.contains(LogicalKeyboardKey.arrowRight) ||
        _keysHeld.contains(LogicalKeyboardKey.keyD)) {
      position.x += _speed * dt;
    }

    // Clamp to virtual screen bounds.
    final halfW = size.x / 2;
    final screenW = gameRef.camera.visibleWorldRect.width;
    position.x = position.x.clamp(halfW, screenW - halfW);

    // ── Auto-fire while SPACE is held ────────────────────────────────────────
    if (_spaceHeld) {
      _autoFireTimer += dt;
      if (_autoFireTimer >= _autoFireRate) {
        _autoFireTimer = 0;
        shootBullet();
      }
    }
  }

  // ── Public API (used by touch D-pad buttons in PlayScreen) ────────────────

  /// Nudge the ship 12 pixels left.  Called on each tap of the ◀ button.
  void moveLeft()  => position.x = (position.x - 12)
      .clamp(size.x / 2, gameRef.camera.visibleWorldRect.width - size.x / 2);

  /// Nudge the ship 12 pixels right.  Called on each tap of the ▶ button.
  void moveRight() => position.x = (position.x + 12)
      .clamp(size.x / 2, gameRef.camera.visibleWorldRect.width - size.x / 2);

  /// Spawn a bullet at the nose of the ship.
  void shootBullet() {
    if (gameRef.isGameOver) return;
    gameRef.add(Bullet(
      startPosition: Vector2(position.x, position.y - size.y / 2),
    ));
  }

  // ── Keyboard handler ──────────────────────────────────────────────────────

  @override
  bool onKeyEvent(KeyEvent event, Set<LogicalKeyboardKey> keysPressed) {
    _keysHeld
      ..clear()
      ..addAll(keysPressed);

    // Fire once on key-down; auto-fire continues if held.
    if (event is KeyDownEvent &&
        event.logicalKey == LogicalKeyboardKey.space) {
      _spaceHeld = true;
      shootBullet();           // immediate first shot
      _autoFireTimer = 0;
    }
    if (event is KeyUpEvent &&
        event.logicalKey == LogicalKeyboardKey.space) {
      _spaceHeld = false;
    }

    return true; // consume the event so it doesn't propagate
  }
}
