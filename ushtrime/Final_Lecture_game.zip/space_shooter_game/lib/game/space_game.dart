// lib/game/space_game.dart
//
// SpaceGame — the root FlameGame class.
//
// WHAT THIS FILE DOES
// -------------------
//   • Extends FlameGame with HasCollisionDetection so every component can
//     declare hitboxes and receive collision callbacks automatically.
//   • Owns the mutable game state: HP and score.
//   • Exposes ValueNotifier<int> for both HP and score so Flutter widgets
//     (HpBar, ScoreDisplay) can rebuild reactively without polling.
//   • Adds the initial components in onLoad():
//       - ScreenHitbox      → invisible boundary; bullets/enemies removed on exit.
//       - Player            → the player's spaceship.
//       - EnemySpawner      → timed enemy factory + speed escalation.
//       - ParallaxComponent → scrolling starfield background (two layers).
//   • applyDamage(int)  → reduces HP, triggers game over when HP ≤ 0.
//   • addScore(int)     → increments score and notifies the widget layer.
//   • triggerGameOver() → pauses the engine. PlayScreen listens to hpNotifier
//                         and performs the Flutter navigation.
//
// GAME DIMENSIONS
// ---------------
//   We fix a virtual resolution of 400 × 700 (portrait mode).
//   Flame's CameraComponent scales this to any physical screen size while
//   preserving the aspect ratio, so the game looks identical on all devices.

import 'dart:async';

import 'package:flame/camera.dart';
import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/foundation.dart' show ValueNotifier;

import 'player.dart';
import 'enemy_spawner.dart';

class SpaceGame extends FlameGame with HasCollisionDetection {
  // ── Game State ─────────────────────────────────────────────────────────────
  int  score     = 0;
  int  hp        = 100;
  bool isGameOver = false;

  // ValueNotifiers bridge Flame state → Flutter widget tree.
  // Add listeners in PlayScreen; never poll these manually.
  final ValueNotifier<int> hpNotifier    = ValueNotifier<int>(100);
  final ValueNotifier<int> scoreNotifier = ValueNotifier<int>(0);

  // Exposed so PlayScreen's D-pad can call player.moveLeft() etc.
  late final Player player;

  // ── onLoad ─────────────────────────────────────────────────────────────────
  @override
  Future<void> onLoad() async {
    await super.onLoad();

    // Fix the virtual game size to 400 × 700 (portrait).
    // Flame will letterbox / pillarbox on screens with different aspect ratios.
    camera.viewfinder.visibleGameSize = Vector2(400, 700);

    // ScreenHitbox is an invisible rectangle matching the screen edges.
    // Components that leave the screen trigger onCollisionEnd so they can
    // remove themselves without an explicit bounds check in update().
    add(ScreenHitbox());

    // ── Scrolling parallax background (two star layers at different speeds) ──
    // Replace 'stars_far.png' and 'stars_near.png' with your own assets.
    // Free packs: https://kenney.nl/assets/space-shooter-redux
    try {
      final parallax = await loadParallaxComponent(
        [
          ParallaxImageData('stars_far.png'),
          ParallaxImageData('stars_near.png'),
        ],
        baseVelocity: Vector2(0, 20),            // base scroll speed (pixels/s)
        velocityMultiplierDelta: Vector2(1, 1.8), // near layer scrolls faster
      );
      add(parallax);
    } catch (_) {
      // Assets not found (common during development before adding sprites).
      // The game still works; the background will be solid black.
    }

    // ── Player spaceship ──────────────────────────────────────────────────────
    player = Player();
    add(player);

    // ── Enemy spawner (also handles speed escalation every 10 s) ─────────────
    add(EnemySpawner());
  }

  // ── Public API called by Enemy and Bullet components ──────────────────────

  /// Subtract [dmg] HP from the player.
  /// Clamps to 0 and triggers game over if HP is exhausted.
  void applyDamage(int dmg) {
    if (isGameOver) return;
    hp = (hp - dmg).clamp(0, 100);
    hpNotifier.value = hp;   // notify HpBar widget
    if (hp <= 0) triggerGameOver();
  }

  /// Add [pts] to the running score.
  void addScore(int pts) {
    score += pts;
    scoreNotifier.value = score;  // notify ScoreDisplay widget
  }

  /// Freeze the game engine.  PlayScreen listens to hpNotifier (value == 0)
  /// and performs the navigation to '/gameover'.
  void triggerGameOver() {
    isGameOver = true;
    pauseEngine();
    // hpNotifier.value is already 0 at this point, which is the signal
    // PlayScreen uses to navigate.
  }

  // ── Cleanup ────────────────────────────────────────────────────────────────
  @override
  void onRemove() {
    hpNotifier.dispose();
    scoreNotifier.dispose();
    super.onRemove();
  }
}
